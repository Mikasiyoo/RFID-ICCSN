function [newtag]= unselect(tag,epc)
newtag=tag;
newtag(ismember(newtag,epc,'rows'),:)=[];



% new_tag=tag;
% new_tag([m],:)=[];%��tag����ĵ�m��Ϊ��




% for nn=1:h
%    result = isequal(new_label,nlabel(nn,:));
%     if result 
%      %disp(nlabel(nn,:));
%      nlabel(nn,:)=[];  
%      h=h-1;
%      break;
%     end
%     %fprintf('\nsucceed');
% end
%         
% end


