clc
clear
tag=[0 0 0 1 0 0 0 1;
     0 0 0 1 1 0 0 1;
     0 0 1 0 0 0 1 0;
     0 1 0 0 1 0 0 0;
     0 1 1 1 0 1 1 1;
     0 1 1 0 0 1 1 0;
     1 1 0 1 0 1 0 1;
     1 1 1 0 1 1 1 1];
w=8;
dui=[];
bit=seekx(tag);
y=yihuo(tag,bit);
dui=xie2(dui,bit,y,w)
ex=dui(end,:);
newtag=formx2(tag,ex)
newbit=seekx(newtag)
y=yihuo(newtag,newbit)
dui=xie2(dui,newbit,y,w)