%z�������bit�����ײλ��1��֮ǰ��λҪ��bit֮ǰ��λ��ͬ
function newtag=formx(tag,bit,high,a)
n=size(tag,1);
j=1;
newtag=tag;
for j=1:n
    epc=tag(j,:);    
    if epc(1,high)==a
        i=high-1;
        while (i>0)
            if epc(1,i)~=bit(1,i)
                newtag=unselect(newtag,epc);
                break;
            else
                i=i-1;                
            end
        end
    else
        newtag=unselect(newtag,epc);
               
    end
end
    