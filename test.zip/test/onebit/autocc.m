clc  %*****autoccϵ���õ��Ǹ���С��3�Ļ��ƣ�������ȫʶ����Զ��������ƣ����������Զ�ʶ�� xie3+qiuhe����yihuo
clear
m=500;  %tag����
n=32;  %EPC��λ��
tag=randsrc(m,n,[0,1]);tag=unique(tag,'rows'); %   ȥ����ͬ����
% tag=lianxu(m,n);
% tag=[0 0 0 1 0 0 0 1;
%      0 0 0 1 1 0 0 1;
%      0 0 1 0 0 0 1 0;
%      0 1 0 0 1 0 0 0;
%      0 1 1 1 0 1 1 1;
%      0 1 1 0 0 1 1 0;
%      1 1 0 1 0 1 0 1;
%      1 1 1 0 1 1 0 1;
%      1 1 1 0 1 1 1 0;
%      1 1 1 1 1 1 1 1];
%   tag= [0     0     0     0     1     0     1     0     0     1     0     1     0     0     0     1;
% 
%      0     0     0     1     0     1     0     1     0     1     0     1     0     0     1     0;
% 
%      0     0     1     0     0     1     1     0     1     1     1     0     1     1     0     0;
% 
%      0     0     1     1     0     0     1     0     1     0     0     1     0     0     1     0;
% 
%      0     0     1     1     1     0     1     0     0     1     0     0     1     1     0     0;
% 
%      0     0     1     1     1     0     1     1     1     0     0     0     0     1     1     1;
% 
%      0     1     0     0     0     1     0     0     0     1     0     1     1     0     0     1;
% 
%      0     1     0     0     0     1     1     0     0     0     1     1     1     0     0     0;
% 
%      0     1     0     0     1     0     1     1     1     1     1     0     0     1     0     0;
% 
%      0     1     0     1     0     0     0     0     1     1     1     0     1     1     0     0;
% 
%      0     1     1     1     0     0     0     0     1     1     1     0     0     0     0     0;
% 
%      1     0     0     0     0     0     1     1     0     0     1     1     1     1     0     0;
% 
%      1     0     0     0     1     1     1     0     1     1     1     1     0     0     0     1;
% 
%      1     0     1     1     1     1     1     0     0     0     1     0     0     1     1     0;
% 
%      1     1     0     1     0     1     1     1     1     1     1     1     0     0     0     0;
% 
%      1     1     0     1     1     1     1     1     0     0     1     0     1     1     1     0;
% 
%      1     1     1     0     0     0     1     1     1     0     1     1     1     0     1     0;
% 
%      1     1     1     0     0     1     1     0     1     0     0     0     0     1     0     1;
% 
%      1     1     1     0     1     0     0     0     0     1     1     0     0     0     1     1;
% 
%      1     1     1     0     1     0     0     0     1     0     1     0     0     0     0     0;];
w=size(tag,2);  %w�Ǿ���new_c�������������Ƶ�λ��
n=size(tag,1); %ȡ�þ���new_c����
count=0;
%*************��ʼ����ǩ����****************

 bit=seekx(tag);
 count=count+1;  %request(11111111)
%  np=sum(bit(1,:)==2) ;  %��ײ��λ��
%  u=np/8;  %������ײ����
 u=1;
 kong=0;
 if u<0.75
     count=backtree2(tag,count)
 else    
     high=find(bit==2,2,'first');
     dui=[];
     y=qiuhe(tag,bit);
     dui=xie3(dui,bit,y,w); %��ʼ����ջ
     atag=tag;
     while(size(dui,1)~=0)
         ex=dui(end,:);%ȡ��ջ���һ��
         newtag=formx2(atag,ex); %��÷���ǰ׺���¾���
         count=count+1;
         while( size(newtag,1)==0)%����γɿ�ʱ϶�����¶���ֱ��ȡ��һ����Ϊ�յ�ʱ϶
             kong=kong+1;
             dui(end,:)=[]; %ɾ����ջ���Ѿ���ѯ����ǰ׺
             ex=dui(end,:);%ȡ��ջ���һ��
             newtag=formx2(atag,ex);
             count=count+1;
         end
         if size(newtag,1)==1
             disp(newtag);
             tag=unselect(tag,newtag);
             dui(end,:)=[];
         else
             newbit=seekx(newtag);
             %          stag=newtag;
%              high=find(newbit==2,2,'first');
             
             aa=size(newtag,1);
             u=1-0.5^aa;
             np=sum(newbit(1,:)==2) ;
             u=np/8;

             if u<0.75
                 stag=newtag;
                 count=backtree2(stag,count);
                 count=count-1;
                 tag=unselect(tag,newtag);
                 dui(end,:)=[];
             else
                 ny=qiuhe(newtag,newbit);
                 dui=xie3(dui,newbit,ny,w);
             end
         end
         
     end
     
 end
 disp('��ȡ����');
 
