clc
clear
tag=[0 0 0 1 0
    0 1 0 1 1;
    0 1 1 0 0;
    1 1 1 1 1];
 bit=seekx(tag);
 w=size(tag,2);
yi=qiuhe3(tag,bit);
dui=[ ];
dui=xie3en(dui,bit,yi,w)
% tag=[0 0 0 0 1;
%     0 0 0 1 1];
% bit=[0 0 0 2 2];
% yi=qiuhe(tag,bit);
% 
% dui1=xie3(dui,bit,yi,w)

