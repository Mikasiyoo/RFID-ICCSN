clc
clear

tag=[100 200 300 400 500 600 700 800 900 1000];
% num_en=[150 300 445 586 738  897 1042 1201 1356 1499];
num_en=[162 326 491 652 811 974 1140 1302 1467 1608];
num_act=[179 356 543 718 899 1055 1245 1424 1604 1810];

num_ams=[185 365 555 731 921 1095 1281 1479 1667 1869];
num_bs=[456 992 1553 2201 2861 3464 4079 4771 5515 6142];


num_8=floor(3.84.*tag);
num_ct=2*tag-1; 
figure(1)
plot(tag,num_ct,'ks-',tag,num_ams,'ro-',tag,num_act,'g>-',tag,num_en,'b*-')
% tag,num_bs,'g>-'
xlabel('Number of tags');
ylabel('Number of total timeslots');
legend('CT','AMS','ACT','NAMCT');

ra_ct=tag./(2.*tag-1);
ra_ams=tag./num_ams;
ra_en=tag./num_en;
 ra_act=tag./num_act;
ra_8=tag./num_8;

figure(2)

plot(tag,ra_ct,'ks-',tag,ra_ams,'ro-',tag,ra_act,'g>-',tag,ra_en,'b*-')
axis([100 1000 0.4 0.7]);
xlabel('Number of tags');
ylabel('System efficiency');
legend('CT','AMS','ACT','NAMCT')

coll_ct=tag-1;
coll_ams=[60 115 180 232 297 350 411 452 524 594];
coll_en=[50 94 140 183 239 286 342 390 455 517];
coll_act=num_act-tag;
figure(3)
plot(tag,coll_ct,'ks-',tag,coll_ams,'ro-',tag,coll_act,'g>-',tag,coll_en,'b*-')

xlabel('Number of tags');
ylabel('Number of collision timeslots');
legend('CT','AMS','ACT','NAMCT')