w=8;
bit=ones(1,w);
D_max=ones(1,w);
new_label=[1 1;0 1;1 0];
new_n=3;
 for k=1:w
   sum=0;
  for jj=1:new_n
  %x=str2num(new_label(jj)); string to number
  %x=bitget(new_label(jj),k);
  sum=sum+new_label(jj,k);    
  end
  if sum==0
        bit(1,k)=0;
    elseif sum==new_n 
        bit(1,k)=1;
    else        
       D_max(1,k)=k;
        bit(1,k)=2;
        %bit=num2str(bit);
       % break;
  end
 end