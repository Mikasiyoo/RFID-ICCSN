high=find(bit==2,1,'first');  %��ײ���λ�±�

newtag=form(tag,high,0);
new_n=size(newtag,1);

while ( newtag~=[])
    newbit=seekx(newtag);
    [new_tag,new_bit,count]=reqtree(newtag,bit,count);
end