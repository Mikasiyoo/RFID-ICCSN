clc
clear
% tag=[1 0 1 0  ;
%      0 0 0 0 ;
%      0 0 1 1 ;
%      0 0  1 0] ;
m=190;  %tag����
n=8;  %EPC��λ��
tag=randsrc(m,n,[0,1]);
tag=unique(tag,'rows'); %   ȥ����ͬ����

bit=[ 0 1 0 0 0 1 1 1];
p=zeros(1,size(tag,2));
i=0;
count=1;
atag=formx(tag,bit,3,1)
tag=[ 0     0     0     0     0     1     0     0;

     0     0     1     0     0     0     0     0;

     0     0     1     0     0     0     1     0;

     0     0     1     1     0     0     0     1;

     0     0     1     1     0     0     1     0;

     0     0     1     1     0     1     1     1;

     0     0     1     1     1     1     0     1];


       