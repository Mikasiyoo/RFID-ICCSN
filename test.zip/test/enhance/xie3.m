function dui=xie3(dui,bit,yi,w)
high=find(bit==2,2,'first');%�����λ����ײλ 1*2�ľ���
n=size(dui,1); %n��dui�����һ��
x=n;
a=any(yi(1,:)==0);
b=any(yi(1,:)==1);
c=any(yi(1,:)==2);
d=any(yi(1,:)==3);
e=a+b+c+d;
if n>0
    hang=dui(end,:);
    dui(end,:)=[ ];
    if d==1
        dui=[dui;hang];
        dui(n,high(1))=1;
        dui(n,high(2))=1;        
    end 
    if c==1
        n=n+d;
        dui=[dui;hang];
        dui(n,high(1))=1;
        dui(n,high(2))=0;
    end
    if b==1
        n=x;
        n=n+d+c;
        dui=[dui;hang];
        dui(n,high(1))=0;
        dui(n,high(2))=1;    
    end
    
    if a==1
        n=x+e-1;
        dui=[dui;hang];
        dui(n,high(1))=0;
        dui(n,high(2))=0;
    end
    n=x;
 
else
    dui=ones(e,w)*2;
    n=1;
    if d==1
        dui(n,high(1))=1;
        dui(n,high(2))=1;
        
    end
    if c==1
        n=n+d;
        dui(n,high(1))=1;
        dui(n,high(2))=0;
    end
    if b==1
        n=1;
        n=n+c+d;
        dui(n,high(1))=0;
        dui(n,high(2))=1;    
    end
    if a==1 
        n=e;
        dui(n,high(1))=0;
        dui(n,high(2))=0;
    end
    n=1;
end

if high(1)>1
    for i=high(1)-1:-1:1
        dui(n:n+e-1,i)=bit(1,i);
    end
end

cha=high(2)-high(1);
if cha>1
    for i=high(1)+1:1:high(2)-1
        dui(n:n+e-1,i)=bit(1,i);
    end
end
    


