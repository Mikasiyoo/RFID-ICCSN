function dui=xie3en(dui,bit,yi,w)
high=find(bit==2,3,'first');%�����λ����ײλ 1*3�ľ���
n=size(dui,1); %n��dui�����һ��
x=n;
a=any(yi(1,:)==0);
b=any(yi(1,:)==1);
c=any(yi(1,:)==2);
d=any(yi(1,:)==3);
e=any(yi(1,:)==4);
f=any(yi(1,:)==5);
g=any(yi(1,:)==6);
h=any(yi(1,:)==7);
z=a+b+c+d+e+f+g+h;
if n>0
    hang=dui(end,:);
    dui(end,:)=[ ];
    if h==1
        dui=[dui;hang];
        dui(n,high(1))=1;
        dui(n,high(2))=1;   
        dui(n,high(3))=1; 
    end 
    if g==1
        n=n+h;
        dui=[dui;hang];
        dui(n,high(1))=1;
        dui(n,high(2))=1;
        dui(n,high(3))=0; 
    end
    if f==1
        n=x;
        n=n+h+g;
        dui=[dui;hang];
        dui(n,high(1))=1;
        dui(n,high(2))=0;  
        dui(n,high(3))=1; 
    end
    
    if e==1
        n=x;
        n=n+h+g+f;
        dui=[dui;hang];
        dui(n,high(1))=1;
        dui(n,high(2))=0;
        dui(n,high(3))=0; 
    end
    if d==1
        n=x;
        n=n+h+g+f+e;
        dui=[dui;hang];
        dui(n,high(1))=0;
        dui(n,high(2))=1;
        dui(n,high(3))=1; 
    end
    if c==1
        n=x;
        n=n+h+g+f+e+d;
        dui=[dui;hang];
        dui(n,high(1))=0;
        dui(n,high(2))=1;
        dui(n,high(3))=0;
    end
    
    if b==1
        n=x;
        n=n+h+g+f+e+d+c;
        dui=[dui;hang];
        dui(n,high(1))=0;
        dui(n,high(2))=0;
        dui(n,high(3))=1;
    end
    if a==1
        n=x;
        n=n+h+g+f+e+d+c+b;
        dui=[dui;hang];
        dui(n,high(1))=0;
        dui(n,high(2))=0;
        dui(n,high(3))=0;
    end
    n=x;
 
else
    dui=ones(z,w)*2;
    n=1;
     if h==1
        dui(n,high(1))=1;
        dui(n,high(2))=1;   
        dui(n,high(3))=1; 
    end 
    if g==1
        n=n+h;
        dui(n,high(1))=1;
        dui(n,high(2))=1;
        dui(n,high(3))=0; 
    end
    if f==1
        n=1;
        n=n+h+g;
        dui(n,high(1))=1;
        dui(n,high(2))=0;  
        dui(n,high(3))=1; 
    end
    
    if e==1
        n=1;
        n=n+h+g+f;
        dui(n,high(1))=1;
        dui(n,high(2))=0;
        dui(n,high(3))=0; 
    end
    if d==1
        n=1;
        n=n+h+g+f+e;
        dui(n,high(1))=0;
        dui(n,high(2))=1;
        dui(n,high(3))=1; 
    end
    if c==1
        n=1;
        n=n+h+g+f+e+d;
        dui(n,high(1))=0;
        dui(n,high(2))=1;
        dui(n,high(3))=0;
    end
    
    if b==1
        n=1;
        n=n+h+g+f+e+d+c;
        dui(n,high(1))=0;
        dui(n,high(2))=0;
        dui(n,high(3))=1;
    end
    if a==1
        n=1;
        n=n+h+g+f+e+d+c+b;
        dui(n,high(1))=0;
        dui(n,high(2))=0;
        dui(n,high(3))=0;
    end
    n=1;
end

if high(1)>1
    for i=high(1)-1:-1:1
        dui(n:n+z-1,i)=bit(1,i);
    end
end

cha=high(2)-high(1);
if cha>1
    for i=high(1)+1:1:high(2)-1
        dui(n:n+z-1,i)=bit(1,i);
    end
end

cha2=high(3)-high(2);
if cha2>1
    for i=high(2)+1:1:high(3)-1
        dui(n:n+z-1,i)=bit(1,i);
    end
end
    


