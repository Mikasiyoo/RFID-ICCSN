clc
clear

tag=[100 200 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500 1600 1700 1800 1900 2000];
%num_en=[150 300 445 586 738  897 1042 1201 1356 1499];
num_amct=[162 326 491 652 811 974 1130 1302 1467 1608 1772 1936 2091 2259 2420 2577 2739 2904 3034 3201];
num_ams=[185 365 555 731 921 1095 1281 1479 1697 1969 2173 2340 2506 2674 2840 3006 3173 3350 3516 3673];
num_act=[179 356 543 718 899 1055 1245 1424 1604 1810 2071 2147 2408 2505 2683 2862 3041 3220 3398 3578];
num_ct=2*tag-1;
num_ict=num_ct-(num_ams-num_act);
%ra_AdATSA=[0.56	0.57 0.58 0.605	0.595 0.606	0.617 0.61 0.605 0.6 0.601 0.602 0.602 0.603 0.606 0.607 0.609 0.611 0.612 0.617];
ra_AdATSA=[0.56	0.57 0.58 0.605	0.595 0.606	0.617 0.61 0.605 0.6 0.602 0.607 0.604 0.602 0.601 0.6 0.603 0.605 0.613 0.609];

num_AdATSA=tag./ra_AdATSA;


ra_OBTT=[0.605 0.604 0.602 0.604 0.602 0.607 0.607 0.603 0.595 0.58 0.59 0.60 0.609 0.603 0.602 0.601 0.602 0.601 0.585 0.58];
num_OBTT=tag./ra_OBTT;
ra_ImATSA=[0.585 0.586 0.578 0.576 0.583 0.589 0.593 0.599 0.556 0.584 0.596 0.601 0.6 0.598 0.594 0.591 0.589 0.581 0.572 0.568];
num_ImATSA=tag./ra_ImATSA;
figure(1) 
plot(tag,num_ict,'k>-',tag,num_act,'go-',tag,num_amct,'r<-',tag,num_AdATSA,'b*-',tag,num_OBTT,'c+-')
%plot(tag,a2,'g>-',tag,a3,'rs-',tag,a4,'ko-',tag,a6,'b*-',tag,a8,'m<-')
xlabel('Number of tags');
ylabel('Number of total timeslots');
legend('ICT','ACT','NAMCT','AdATSA','OBTT');
axes('position',[0.21 0.53 0.26 0.362])
hold on 
m1=17;
m2=20;
plot(tag(m1:m2),num_ict(m1:m2),'k>-',tag(m1:m2),num_act(m1:m2),'go-',tag(m1:m2),num_amct(m1:m2),'r<-',tag(m1:m2),num_AdATSA(m1:m2),'b*-',tag(m1:m2),num_OBTT(m1:m2),'c+-')
axis tight
hold off

figure(2) 
plot(tag,tag./num_ict,'k>-',tag,tag./num_act,'go-',tag,tag./num_amct,'r<-',tag,ra_AdATSA,'b*-',tag,ra_OBTT,'c+-')
axis([100 2000 0.4 0.7]);
xlabel('Number of tags');
ylabel('System efficiency');
legend('ICT','ACT','NAMCT','AdATSA','OBTT');

ra_ict=tag./num_ict;
ra_act=tag./num_act;
ra_namct=tag./num_amct




coll_ct=tag-1;
coll_ict=num_ict-tag;
%coll_ams=[60 115 180 232 297 350 411 452 524 594 659 712 829 897 956 1013 1070 1124 1196];
coll_en=[50 94 130 183 239 286 342 390 455 517 549 600 649 699 749 796 848  866 928 976];
coll_act=num_act-tag;
coll_AdATSA=[61 119 183 242 301 355 421 476 541 599 662 717 782  833 902 961 1022 1083 1139 1204];
coll_imATSA=[55	97	112	162	290	225	291	374	451	538	354	419	503	568	645	710	807	871	968	1064];
%coll_OBTT=[55 97 110 162 221 190 257 287 302 368 407 342 328 395  407 460 460 475 498 530];
coll_OBTT=[70 130 192 286  321 389 468 490 550 600 664 723 777  832 874 921 955 1010 1060 1100];
figure(3)
plot(tag,coll_ict,'k>-',tag,coll_act,'go-',tag,coll_en,'r<-',tag,coll_AdATSA,'b*-',tag,coll_OBTT,'c+-')
xlabel('Number of tags');
ylabel('Number of collision timeslots');
legend('ICT','ACT','NAMCT','AdATSA','OBTT');

