clc
clear

m=1000;
k=log(m/4)/log(8);
k=floor(k);

collk=[8^(k+1)]*[1-(1-8^(-k-1))^m-(m/8^(k+1))*(1-8^(-k-1))^(m-1)]%���һ�����ײ����
k=k+1;
collk2=[8^(k+1)]*[1-(1-8^(-k-1))^m-(m/8^(k+1))*(1-8^(-k-1))^(m-1)];
duqu=m*(1-8^(-k-1))^(m-1);
% t=2*(m-1)/3-2*collk+collk*2+m
% t=2*(m-1-collk)/3+collk*1.5-duqu+m
 t=0.48*m+m-0.5*collk