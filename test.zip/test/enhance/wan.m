clc
clear
m=0;
tag=[1100 1200 1300 1400 1500 1600 1700 1800 1900 2000];
%tag=[100 200 300 400 500 600 700 800 900 1000];
tt=zeros(1,10);
for i=1:10
 
    a=log(tag(i)/3);
    b=a/log(4);
    m=floor(b);
    s=0;
    for j=1:m
        s=s+power(4,j);
    end

    s=s+5/3*tag(i);
    tt(i)=s;
   
end
tt
