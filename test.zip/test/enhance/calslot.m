clc
clear
m=200;
k=log(m/4)/log(8);
k=floor(k);
% k=k+1;
T8ary=0;
T=0;
for i=0:k
    T8ary=T8ary+8.^i;
end
% gain=(8^k)*(1-(1-8^(-k))^m-m/(8^k)*(1-8^(-k))^(m-1));%m*((1-8^(-k-1))^(m-1));
% T2ary=gain*(2*3-1);
T2ary=5/4*m;

collk=[8^(k+1)]*[1-(1-8^(-k-1))^m-(m/8^(k+1))*(1-8^(-k-1))^(m-1)]%���һ�����ײ����
T8coll=0.48*m-collk;

zend=(8.^(k+1))*((1-8.^(-k-1)).^m);
T8idle=2.36*m-(8.^(k+1))*((1-8.^(-k-1)).^m);

T=2.84*m+T2ary-T8idle+T8coll;



% k=log(m/3)/log(4);
% k=floor(k);
% T4ary=0;
% T=0;
% for i=0:k
%     T4ary=T4ary+4.^i;
% end
% T2ary=5/3*m;
% zend=[4.^(k+1)]*[(1-4.^(-k-1)).^m];
% T4idle=1.16*m-(4.^(k+1))*((1-4.^(-k-1)).^m);
% collk=[4^(k+1)]*[1-(1-4^(-k-1))^m-(m/4^(k+1))*(1-4^(-k-1))^(m-1)];
% T4coll=0.72*m-collk;
% T=T4ary+T2ary-T4idle+T4coll
