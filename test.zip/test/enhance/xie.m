function dui=xie(dui,bit,w)%д���ʼ��ǰ׺ 
high=find(bit==2,2,'first');%�����λ����ײλ 1*2�ľ���
n=size(dui,1);
if n>0
    hang=dui(end,:);
    for i=1:3
        dui=[dui;hang];
    end
else
    dui=ones(4,w)*2;
    n=n+1;
end
if high(1)>1
    for i=high(1)-1:-1:1
        dui(n:n+3,i)=bit(1,i);
    end
end

a=high(2)-high(1);
if a>1
    for i=high(1)+1:1:high(2)-1
        dui(n:n+3,i)=bit(1,i);
    end
end

dui(n,high(1))=1;
dui(n,high(2))=1;
dui(n+1,high(1))=1;
dui(n+1,high(2))=0;
dui(n+2,high(1))=0;
dui(n+2,high(2))=1;
dui(n+3,high(1))=0;
dui(n+3,high(2))=0;
